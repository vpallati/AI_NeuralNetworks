
import neurolab as nl
import numpy as np
import pandas as pd

trainInput = pd.read_csv('TrainInput.csv')
trainTarget = pd.read_csv('TrainTarget.csv')
testInput = pd.read_csv('TestInput.csv')
testTarget = pd.read_csv('TestTarget.csv')

# Create network with 2 inputs, 5 neurons in input layer and 1 in output layer
net = nl.net.newff([[11.0, 15.0],
                    [0.0, 6.0],
                    [1.0, 4.0],
                    [10.0, 31.0],
                    [69.0, 164.0],
                    [0.0, 4.0],
                    [0.0, 6.0],
                    [0.0, 1.0],
                    [0.0, 4.0],
                    [0.0, 14.0],
                    [0.4, 1.8],
                    [1.2, 4.1],
                    [270.0, 1700.0]], [50, 1])



net.trainf = nl.train.train_gdx

# Train network
error = net.train(trainInput, trainTarget, epochs=1000,lr_inc=1.05, lr_dec=0.7, max_perf_inc= 1.05,  show=1, lr=0.1,adapt=True,mc=0.01)

# Simulate network
out = net.sim(trainInput)

# Plot result
import pylab as pl
pl.subplot(211)
pl.plot(error)
pl.xlabel('Epoch number')
pl.ylabel('error (default SSE)')
pl.show()

