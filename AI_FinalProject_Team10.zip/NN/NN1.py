
import neurolab as nl
import numpy as np
import pandas as pd

trainInput = pd.read_csv('TrainInput.csv')
trainTarget = pd.read_csv('TrainTarget.csv')
testInput = pd.read_csv('TestInput.csv')
testTarget = pd.read_csv('TestTarget.csv')



trainTarget['1'] = trainTarget['1'].map({1: 0, 2: 0.5, 3:1})

# Create network with 2 inputs, 5 neurons in input layer and 1 in output layer
net = nl.net.newff([[11.0, 15.0],
                    [0.0, 6.0],
                    [1.0, 4.0],
                    [10.0, 31.0],
                    [69.0, 164.0],
                    [0.0, 4.0],
                    [0.0, 6.0],
                    [0.0, 1.0],
                    [0.0, 4.0],
                    [0.0, 14.0],
                    [0.4, 1.8],
                    [1.2, 4.1],
                    [270.0, 1700.0]], [10,1])


net.errorf = nl.error.SSE() 
net.trainf = nl.train.train_gdx

# Train network
error = net.train(trainInput, trainTarget, epochs=1000, show=1, lr=0.00001, goal=0.01, mc=0.0001)

# Simulate network
out = net.sim(trainInput)

# Plot result
import pylab as pl
pl.subplot(211)
pl.plot(error)
pl.xlabel('Epoch number')
pl.ylabel('error (default SSE)')
pl.show()

